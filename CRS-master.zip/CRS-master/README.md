
//# CRS
// CHOPHOUZE Recording Studio (or CHOPHOUZE Records?)
// Intially, this site is to be for CHOPHOUZE Recording Studio.  As of November 17th, 2016, I'm thinking perhaps it should be CHOPHOUZE records.

https://ldpj.github.io/CRS/

// <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/">Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License</a>.
